const { Client } = require('discord-rpc');
const rpc = new Client({ transport: 'ipc' });

const clientId = '1312592276744306718';  // Use your actual Client ID

// Create an async function to set the activity
(async () => {
    rpc.on('ready', async () => {  // Event that triggers when the RPC client is ready
        try {
            await rpc.setActivity({ // Set the Rich Presence Activity
                details: '⚔️ Chronicles of The Exiles ⚔️',  // Main activity description
                state: '⚔️ RP - Join us Today ⚔️',  // State description
                startTimestamp: new Date(),
                largeImageKey: 'https://i.postimg.cc/76DX6vRD/Chronicles-of-The-Exiles.webp', // Image (max 512x512px)
                largeImageText: 'Direct Connect: 51.81.129.125:21912',  // Tooltip for the large image

                // Detailed information in the 'state' field (Separate info in one field)
                state: '⚔️ RP - Join us Today ⚔️\n' + 
                       '🌐 Website: https://coe.harleytg.online\n' +
                       '💬 Discord: https://discord.gg/4bnthJMpcw\n' + 
                       '🔗 Direct Connect: 51.81.129.125:21912'
            });

            console.log("⚔️ Rich Presence Activity has been enabled with separate details! ⚔️");
        } catch (err) {
            console.error('Error setting activity:', err);
        }
    });

    // Log in to Discord with the provided client ID
    try {
        await rpc.login({ clientId });
    } catch (err) {
        console.error('Error logging into Discord:', err);
    }
})();
